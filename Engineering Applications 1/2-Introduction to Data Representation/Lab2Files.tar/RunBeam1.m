 % RunBeam1.m
 % [Your Name]
 % [Date Modified]
 % Based on: RunCan.m
 % Written by: Michael R. Gustafson II (mrg@duke.edu)

 % I have adhered to all the tenets of the 
 % Duke Community Standard in creating this code.
 % Signed: [Your acpub login ID]
