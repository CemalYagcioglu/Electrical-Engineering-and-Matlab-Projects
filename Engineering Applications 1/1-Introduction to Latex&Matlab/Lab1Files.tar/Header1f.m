 % [Function or Script Name]
 % [Your Name]
 % [Date Modified]

 % I understand and have adhered to all the tenets of the 
 % Duke Community Standard in creating this code.  I understand 
 % that a violation of any part of the Standard on any part of 
 % this assignment can result in failure of this assignment, 
 % failure of this course, and/or suspension from Duke University. 
 % Signed: [Your NetID]
