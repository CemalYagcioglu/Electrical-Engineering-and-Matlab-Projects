% PlotCharge.m
% [Name]
% [Date Modified]
% Based on: PlotCharge.m
% Written by: Michael R. Gustafson II

% I have adhered to all the tenets of the
% Duke Community Standard in creating this code.
% Signed: [Your NetID]


%% Initialize workspace
clear; format short e

%% Make plot
% Initialize plot
figure(1); clf
% Generate time base
t = linspace(0, .8, 1000);
% Calculate charge values using function
q = Charge(t, 10, 60, 9, .000005);
% Make plot
plot(t, q, 'k-')
% Add commands for labels, titles, grid, and saving plot here