% [Function or Script Name]
% [Your Name]
% [Date Modified]
%
% I have adhered to all the tenets of the 
% Duke Community Standard in creating this code.
% Signed: [Your NetID]

%% Initialize the workspace

%% Create vector of volumes and vectors for each gas

%% Start and clear figure

%% Set increment for point plots and plot points and lines

%% Add title, labels, then print

print -deps PressuresPlot