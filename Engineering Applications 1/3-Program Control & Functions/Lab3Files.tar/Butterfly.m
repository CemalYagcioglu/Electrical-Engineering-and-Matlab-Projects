function [x, y] = Butterfly(t)
% [Function or Script Name]
% [Your Name]
% [Date Modified]
%
% I have adhered to all the tenets of the 
% Duke Community Standard in creating this code.
% Signed: [Your NetID]

%% Equations for x and for y in terms of t here
