function qout = Charge(t, q0, R, L, C)
% Honor code and help file if desired

%% Error checking


%% Calculation
qout = t.*0;