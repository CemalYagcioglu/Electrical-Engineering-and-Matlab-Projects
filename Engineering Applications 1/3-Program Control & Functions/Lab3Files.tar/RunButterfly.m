% [Function or Script Name]
% [Your Name]
% [Date Modified]
%
% I have adhered to all the tenets of the 
% Duke Community Standard in creating this code.
% Signed: [Your NetID

%% Initialize workspace

%% Set up variable to store times and use Butterfly 
%  function to get vectors for x and y coordinates


%% Make plot, add grid, labels and titles, then print

print -deps ButterflyPlot % You're welcome!